import { loadTranslations, getUserLanguage } from '../../translations/index.js';

export function Video({ mode = 'play', videoUrl = '', onBase64Ready = null }) {
    // Obtener el idioma del usuario y cargar las traducciones
    const userLanguage = getUserLanguage();
    const translations = loadTranslations(userLanguage);

    if (mode === 'play') {
        //Reproducción de Video
        return `
            <div>
                <video id="video" controls width="320" height="240" src="${videoUrl}"></video>
            </div>
        `;
    }
    //Grabación de Video
    return `
        <div>
            <div class="form-group">
                <label for="camera-select">${translations.videoComponent_cameraSelectLabel}</label>
                <select id="camera-select" class="form-control"></select>
            </div>
            <div class="form-group">
                <label for="mic-select">${translations.videoComponent_micSelectLabel}</label>
                <select id="mic-select" class="form-control"></select>
            </div>

            <div id="countdown" style="font-size: 2rem; display: none; color: red; text-align: center;">${translations.videoComponent_countdown}</div>

            <button id="start-video-btn" class="btn btn-primary">${translations.videoComponent_startRecordingButton}</button>
            <button id="pause-btn" class="btn btn-warning" style="display: none;">${translations.videoComponent_pauseButton}</button>
            <button id="stop-btn" class="btn btn-danger" style="display: none;">${translations.videoComponent_stopButton}</button>
            <a id="download-btn" class="btn btn-success" style="display: none;">${translations.videoComponent_downloadButton}</a>

            <video id="video-preview" width="320" height="240" controls></video>
        </div>
    `;
}
// Pausar o reanudar la grabación
function togglePauseRecording() {
    const pauseBtn = document.getElementById('pause-btn');
    const videoElement = document.getElementById('video-preview');

    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.pause();
        pauseBtn.innerText = 'Reanudar';
        videoElement.pause();
    } else if (mediaRecorder && mediaRecorder.state === 'paused') {
        mediaRecorder.resume();
        pauseBtn.innerText = 'Pausar';
        videoElement.play();
    }
}
// Detener la grabación
function stopRecording() {
    if (mediaRecorder) {
        mediaRecorder.stop();

        // Detener el stream de la cámara
        stream.getTracks().forEach(track => track.stop());

        document.getElementById('pause-btn').style.display = 'none';
        document.getElementById('stop-btn').style.display = 'none';
    }
}
// Cargar los dispositivos multimedia (cámaras y micrófonos)
export async function loadMediaDevices() {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoInputDevices = devices.filter(device => device.kind === 'videoinput');
    const audioInputDevices = devices.filter(device => device.kind === 'audioinput');

    // Popular las listas de cámaras y micrófonos
    const cameraSelect = document.getElementById('camera-select');
    const micSelect = document.getElementById('mic-select');
    
    videoInputDevices.forEach(device => {
        const option = document.createElement('option');
        option.value = device.deviceId;
        option.text = device.label || `Cámara ${cameraSelect.length + 1}`;
        cameraSelect.appendChild(option);
    });

    audioInputDevices.forEach(device => {
        const option = document.createElement('option');
        option.value = device.deviceId;
        option.text = device.label || `Micrófono ${micSelect.length + 1}`;
        micSelect.appendChild(option);
    });
}
// Lógica de eventos después de renderizar el componente Video
export function setupVideoEvents(onBase64Ready) {
    // Cargar los dispositivos multimedia
    loadMediaDevices();

    // Iniciar grabación de video
    document.getElementById('start-video-btn').addEventListener('click', () => {
        const selectedCamera = document.getElementById('camera-select').value;
        const selectedMic = document.getElementById('mic-select').value;
        handleVideoRecording(selectedCamera, selectedMic, onBase64Ready);
    });

    // Pausar/reanudar grabación
    document.getElementById('pause-btn').addEventListener('click', togglePauseRecording);

    // Detener grabación
    document.getElementById('stop-btn').addEventListener('click', stopRecording);
}
